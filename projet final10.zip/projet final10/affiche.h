#include<stdlib.h>
#include<stdio.h>

#ifndef affiche_h
#define affiche_h
#include"monde.h"

void affiche(liste *);

void afficher_animal(animal *A);

void afficher_distance(int *liste_dist,int compte);
void affiche_toutes_les_familles(liste **init,int compte);
void afficher_liste(liste *L);
void afficher_maillon(maillon *m);
void affiche_position(position *pos);

#endif
