#include"affiche.h"
#include"monde.h"
#include<stdio.h>
#include<stdlib.h>

void affiche(liste *L) {
  maillon *p = L->tete;
  while (p) {
    printf("%d (%d) -> ", p->id, p->ani->energie);
    p = p->next;
  }
  printf("\n");
}

void afficher_animal(animal *A){
  if(A==NULL){
    printf("animal NULL\n");
    return;
  }
  printf("\nLa direction de l'animal est=%d \n",A->direction);
  printf("\nEnergie est de=%d",A->energie);
  affiche_position(&A->pos);
  for(int i=0;i<8;i++){
    printf("Le gene num %i est =%d\n",i,A->chromosome[i]);
  }
}

void afficher_maillon(maillon *m){
  if(m!=NULL){
    afficher_animal(m->ani);
  }
}

void affiche_position(position *pos){
  printf("\nposition i=%d\n",pos->i);
  printf("position j=%d\n",pos->j);
}

void afficher_liste(liste *L){

  maillon *y=L->tete;
  while(y!=NULL){
    afficher_animal(y->ani);
    y=y->next;
  }
}

void affiche_toutes_les_familles(liste **init,int compte){
  if(init==NULL || *init==NULL) return;
  printf("Le nombre de descandances qui restent est de %d\n",compte);
  for(int i=0;i<compte;i++){
  	if(init[i]->tete){
      printf("\nVOICI FAMILLE DESCENDANTS animal numero :%d \n",i+1);
      afficher_liste(init[i]);
      }
   }
}

void afficher_distance(int *liste_dist,int compte){
  for(int k=0;k<compte;k++){
      printf("Les distances des animaux sont %d=%d \n",k,liste_dist[k]);
  }
}
