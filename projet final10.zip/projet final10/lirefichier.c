#include<stdio.h>
#include<stdlib.h>
#include"monde.h"
#include"affiche.h"
#include"lirefichier.h"
#define N_char 255

void lire_monde(FILE *f,int Tab[]){
  char line[N_char];
  fscanf(f,"Monde %d %d",&Tab[0],&Tab[1]);
  printf("MONDE hauteur=%d    \n longueur=%d",Tab[0],Tab[1]);
  fgets(line,Taille,f);
  fscanf(f," Beauce %d %d %d %d \n",&Tab[2],&Tab[3],&Tab[4],&Tab[5]);
  fscanf(f,"Energie Nourriture %d",&Tab[6]);
  fgets(line,Taille,f);
  fscanf(f,"Seuil Reproduction %d",&Tab[7]);
}

void detruire_liste(liste *L){ //libere dans la memoire
  if(L==NULL){return;}
  maillon* n;
  animal *A;
  while(L->tete!=NULL){
    //affiche(L);

         n=L->tete;
         A=n->ani;
         L->tete=L->tete->next;
         printf("***** free maillon DET: %d\n", n->id);

         free(n);
         A->compteur--;
         if (A->compteur==0) {
             printf("**** free animal DET: %d (%p)\n", A->energie, A);
            free(A);
          }
          }
          if(L!=NULL)free(L);
    return;
    }

void detruire_desc(liste **init,int compte){ //dectruit la liste des descenfances
  for(int i=0;i<compte;i++){
    detruire_liste(init[i]);
  }
  free(init);
  return;
  }

void lire_animaux(FILE *f,liste *L){//lit les animaux

    char line[Taille];
    fgets(line, Taille,f);
    long pos=ftell(f);
    rewind(f);
    int compte=0;

    while(fgets(line, Taille,f)!= NULL && (line[0]!='(')){};
   	while(fgets(line, Taille,f)!= NULL && line[0]=='('){
          compte++;
       }
    compte++;
    printf("le nombre danimaux presents initialment dans le monde est %d",compte);
    fseek(f,pos,SEEK_SET);
//    animal *TEMP=malloc(sizeof(animal)*compte);
    for(int co=0;co<compte;co++){
        animal *TEMP = malloc(sizeof(animal));
        fscanf(f,"(%d %d) %d %d | ",&(TEMP->pos.i),&(TEMP->pos.j),&(TEMP->direction),&(TEMP->energie));
        int g=0;
        int c=fgetc(f);
        while((g<8)&(c!=EOF)){
            if (c!=' '){
              TEMP->chromosome[g]=c-'0';
              g++;
            }
            c=fgetc(f);
        }
        TEMP->compteur = 0;
        ajout_liste(L,TEMP);
        fgets(line, Taille,f);
    }
  //  afficher_liste(L);
    fclose(f);
}
