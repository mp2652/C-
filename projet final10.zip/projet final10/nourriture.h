#include<stdlib.h>
#include<stdio.h>
#include"monde.h"
#ifndef nourriture_h
#define nourriture_h



nourriture * init_nourriture(int h,int l,int hb, int lb,int ib,int jb);
int presencenourriture(position *p,nourriture *nourriture);
 nourriture *gener_nourriture(nourriture *N,int h,int l,int ib,int jb,int hb,int lb);
void affiche_nourriture(nourriture *N);


#endif