#include<stdlib.h>
#include<stdio.h>
#include"nourriture.h"
#include"monde.h"
#ifndef image_h
#define image_h

typedef struct{
        int r;
        int v;
        int b;
        int ene;
} Pixel;


typedef struct{
    Pixel **pixel;
    int h,l;
}image;

void remplir_matrix(Pixel **m, int l, int h,int ib,int jb,int lb,int hb,nourriture *N,liste **init,int compte);
void SaveImage(image img, FILE *returnfile);
int ListRecherchePosition(maillon *tete,int i,int j);
int comparePixel(Pixel p1,Pixel p2);

animal *AniInd(liste *L,int k);

#endif
