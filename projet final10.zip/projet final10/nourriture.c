
#include"monde.h"
#include"nourriture.h"
#include"affiche.h"
#include<stdio.h>
#include<stdlib.h>
#include<time.h>

nourriture * init_nourriture(int h,int l,int hb, int lb,int ib,int jb){// initialise  la nourriture a la creation du monde

  nourriture * N=malloc(sizeof(nourriture));
  if(N==NULL){
    printf("ERREUR malloc nouriture");
    exit(EXIT_FAILURE);
  }
  N->nombre=1;
  printf("nombre %d",N->nombre);
  position *TAB_N=malloc(2*N->nombre*sizeof(position));

  if (TAB_N==NULL){
      printf("ERREUR malloc pointeur de tableau");
      exit(EXIT_FAILURE);
  }
  N->TAB_N=TAB_N;
  for(int k=0;k<N->nombre;k++){            //on remplit le monde
    N->TAB_N[k].i=rand()%(h);
    N->TAB_N[k].j=rand()%(l);
  }
  for (int k=N->nombre;k<2*N->nombre;k++){ //on remplit la beauce
    N->TAB_N[k].i=ib+(rand()%(hb));
    N->TAB_N[k].j=jb+(rand()%(lb));
  }
  return N;
}

int presencenourriture(position *p,nourriture *nourriture){ //indique s'il y a de la nourriture dans une case donnée
  for(int k=0;k<nourriture->nombre;k++){
    if (nourriture->TAB_N[k].i==p->i && nourriture->TAB_N[k].j==p->j){
      return 1;
    }
  }
  return 0;
}



nourriture *gener_nourriture(nourriture *N,int h,int l,int ib,int jb,int hb,int lb){//genere de la nourriture pour chaque tour

  N->TAB_N=realloc(N->TAB_N,(2*N->nombre+2)*sizeof(position));
  if (N->TAB_N==NULL){
    printf("ERREUR");
    exit(EXIT_FAILURE);
  }

  N->TAB_N[N->nombre+1].i=(ib+(rand())%(hb)); //dans la beauce
  N->TAB_N[N->nombre+1].j=(jb+(rand())%(lb));

  N->TAB_N[N->nombre].i=rand()%(h);           //dans le monde
  N->TAB_N[N->nombre].j=rand()%(l);

  N->nombre+=2;
  return N;
}



void affiche_nourriture(nourriture *N){ //affiche toutes les positions ou la nourriture se trouve
  for(int k=0;k<N->nombre;k++){
    affiche_position(&N->TAB_N[k]);
  }
}
