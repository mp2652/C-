#include<stdlib.h>
#include<stdio.h>
#ifndef monde_h
#define monde_h
#define Taille 1000

int freeListe;

typedef struct{
  int h,l;
}monde;


typedef struct{
int i;
int j;
}position;

typedef struct{
  int nombre;
  position *TAB_N;
}nourriture;



typedef struct{
  int compteur;
  int chromosome[8];
  position pos;
  int direction;
  int energie; //compris entre 0 et  7;
}animal;

//element de la liste chaine qui contient le pointeur
typedef struct m{
  int id;
  animal *ani;
  struct m *next;
}maillon;

// liste chaine qui contient les animaux
typedef struct{
  int compteur;
  int taille;
  maillon *tete;
}liste;

liste *init_list(void) ;
void ajout_liste(liste *L,animal* ele);



#endif
