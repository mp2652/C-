#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include"image.h"
#include <math.h>
#include"nourriture.h"
#include"monde.h"


int ListRecherchePosition(maillon *tete,int i,int j){//si present renvoie l'indice de l'animal qui est dans cette position et renvoie -1 sinon
  int k=0;
  for(maillon *m=tete;m!=NULL;m=m->next){
    k++;
    if(m->ani->pos.i==i && m->ani->pos.j==j){
      return k;
    }
  }
  return -1;
}


animal *AniInd(liste *L,int k){
  int i=1;
  if(k==0){
    return L->tete->ani;
  }
  maillon *m=L->tete;
  while (i<k){
    i++;
    m=m->next;
  }

  return m->ani;// m nest pas egale a null k est lindice renvoie par une fonction qui verfie la presence dun animal a cette indice
}

int comparePixel(Pixel p1,Pixel p2){
  if((p1.r==p2.r)&&(p1.v==p2.v)&&(p1.b==p2.b)){
    return 1;
    }
  return 0;
}

void remplir_matrix(Pixel **m, int l, int h,int ib,int jb,int lb,int hb,nourriture *N,liste **init,int compte){

    Pixel Bc,nourriture;
    Pixel M;
    Bc.r=0;//vert
    Bc.v=255;
    Bc.b=0,Bc.ene=0;
    M.r=255;//jaune
    M.v=255;
    M.b=0,M.ene=0;
    nourriture.r=255,nourriture.v=70,nourriture.b=0,nourriture.ene=0;
    Pixel coulAni;
    int ind=0;
    for(int i=0; i<h; i++){
        for(int j=0; j<l; j++){
          //on place la Beauce vert
          if ((i>=ib && i<=(ib+hb) && j>=jb && j<=(jb+lb))||(i>=ib && i<=(ib+hb)%h && j>=jb && j<=(jb+lb)%l)){
            m[i][j]=Bc;
          }
          //sinon cest une case vide jaune du monde
          else{
              m[i][j]=M;
          }
        // on place la nouriture en rouge
        position p;
        p.i=i;
        p.j=j;

        if (presencenourriture(&p,N)){
            m[i][j]=nourriture;
        }

        for(int k=0;k<compte;k++){//k est le numero de la famille
          // printf("avant calcul k=%d ind ***\n",k);
          ind=ListRecherchePosition(init[k]->tete,i,j);//init[k][ind] coreespond a lanimal dans cette position
          // printf("apres calcul ind =%d****\n",ind);
          if(ind!=-1){//il ya un animal dans cette position
            if(AniInd(init[k],ind)==NULL){
               return;
            }
           //la couleur est forcement differente
           // max=MaxEnergie(init[k]->tete)
             coulAni.r=(k+1)/(compte+1);
             coulAni.v=120;
             coulAni.b=((k+1)*255)/(compte+1);
             coulAni.ene=AniInd(init[k],ind)->energie;//ne peut jamais etre egale a 255 car k<compte

              if(comparePixel(m[i][j],M)==0 && comparePixel(m[i][j],nourriture)==0&&comparePixel(m[i][j],Bc)==0){// dans ce cas il ya deja un animal
                  if(AniInd(init[k],ind)==NULL){
                    printf("ani null\n");return;
                  }
                  if((AniInd(init[k],ind))->energie>(m[i][j]).ene){
                    m[i][j]=coulAni;//on met la couleur de lanimal qui a le plus denergie
                  }
              }
              else{
                m[i][j]=coulAni;
              }
           }
          }
       }
    }
}


void SaveImage(image img, FILE *returnfile){
    int i,j;

    if(returnfile==NULL){
        printf("ERREUR DE CREATION DU FICHIER DE SORTIE \n");
        exit(11);
    }

    fprintf(returnfile,"%s\n%u %u\n255\n","P3",img.l,img.h);

    for(i=0;i<img.h;i++){
        for(j=0;j<img.l;j++){
            fprintf(returnfile,"%d %d %d ",img.pixel[i][j].r,img.pixel[i][j].v,img.pixel[i][j].b);
        }
    }
    for(i=0;i<img.h;i++){
          free(img.pixel[i]);
        }

    free(img.pixel);
    fclose(returnfile);
}
