#include<stdlib.h>
#include<stdio.h>
#include"monde.h"
#ifndef deplace_h
#define deplace_h

void mutation(animal *animal);
int geneactive(int chromosome[]);
void deplacement(animal* animal,int h,int l,nourriture *nourriture,liste *L,int energie,int seuil_reprod,liste **init,int *compte);
void etatenergie(animal * A,nourriture *nourriture,liste *L,int energie,int seuil_reprod,liste **init,int *compte);
 void reproduction (liste **init,liste *L,animal *ani);
int RechercheDansListe(liste **init,animal *A,int compte);
  void RemoveTime(liste *L,animal *ele);
  int ListeRechercheAnimal(liste *L,animal *A);//retourne 1 si A est dans la liste, 0 si non 
  #endif
