#include<stdio.h>
#include<stdlib.h>
#include"monde.h"
#include"nourriture.h"
#include"affiche.h"
#include"lirefichier.h"
#include"deplace.h"
#include<time.h>
#define N_char 255


int ListeRechercheAnimal(liste *L,animal *A){//retourne 1 si A est dans la liste, 0 si non
  if(L==NULL){return 0;}
  for(maillon *m=L->tete;m!=NULL;m=m->next){
    if(m->ani==A){
      return 1;
    }
  }
  return 0;
}

void RemoveTime(liste *L,animal *ele){ //Parcours la liste pour supprimer un animal
  maillon *m=L->tete;
  if(m==NULL){
    printf("liste vide");
    return;
  }
  printf("On supprime un element dans RemoveTime\n");
  L->taille--;
  printf("la nouvelle taille de la liste est L->taille=%d\n",L->taille);
  if(m->ani==ele){
    maillon *p=L->tete;
    L->tete=L->tete->next;
    p->ani->compteur--;
    if (!p->ani->compteur) {
        printf("**** free animal (time) : %d\n", p->ani->energie);
        free(p->ani);
    }
    printf("***** free maillon (time): %d\n", p->id);
    free(p);
  }
  else{
    while(m->next!=NULL){
      if(m->next->ani==ele){
        maillon *p=m->next;
        m->next=p->next;
        p->ani->compteur--;
        if (!p->ani->compteur) {
          printf("**** free animal (time) : %d\n", p->ani->energie);
            free(p->ani);
        }
        printf("***** free maillon (time): %d\n", p->id);
        free(p);
        return;
      }
      m=m->next;
    }
  }
}

int RechercheDansListe(liste **init,animal *A,int compte){//renvoie lindice de la liste dans lequelle il se trouve et -1 si non
  if(init==NULL)return -1;
  for(int i=0;i<compte;i++){
    if(ListeRechercheAnimal(init[i],A)==1){
      return i;
    }
  }
  printf("Lanimal ne fait pas parti des generations \n");
  return -1;
  }

void  SupprimerDansListe(liste **init,animal *A,int *compte){ //supprime une liste de liste
  int j,numListe=RechercheDansListe(init,A,*compte);

  if (numListe!=-1){
    if((init[numListe]->tete->ani==A) & (init[numListe]->tete->next==NULL)){
    liste *temp=init[numListe];
      for(j=numListe;j<*compte-1;j++){
          init[j]=init[j+1];
        }
    init[*compte-1]=NULL;
    //temp->tete->ani->compteur--;
    //printf("***** Malloc maillon : %d\n", temp->tete->id-1);
    printf("mallion free");
    detruire_liste(temp);
  //  freeListe--;
    //free(temp->tete);
    printf("le nombre de desendants dans supprim ant denlever est %d\n",*compte);
    *compte-=1;

    }
    else{
      RemoveTime(init[numListe],A);
    }
  //  affiche_toutes_les_familles(init,*compte);
  }
  else{
    printf("lanimal ne fait pas partie dapres SupprimerDansListe\n");
    return;
    }
}

void mutation(animal *animal){ //provoque une mutation de -1 ou de 1 sur un chromosome aleatoire
  int random,uniform;
  random=rand()%8;
  uniform=rand()%3;
  switch(uniform){
    case(0):
      if (animal->chromosome[random]==1){
         break;
      }
      else{
         animal->chromosome[random]-=1;
       break;
      }
    case(1):
         break;
    case(2):
          animal->chromosome[random]+=1;
           break;
    default:
          break;
  }
}

int geneactive(int chromosome[]){ //active le gene d'un animal avec probabilite demandé
  printf("gene active\n");
  int i,somme=0,j,k=0,p;
  for( i=0;i<8;i++){
    somme=somme+chromosome[i];
  }
  int *tab=malloc(somme*sizeof(int));
  if(tab==NULL){
    printf("malloc de tab ERREUR dans geneactive,verifier si la somme des genes est negatifs \n");
    return -1;
  }
  for(i=0;i<8;i++){
    for(j=0;j<chromosome[i];j++){
      tab[k]=chromosome[i];
      k++;
    }
  }
  p=rand()%somme;
  i=0;
  k=0;
  while (i<=p){
    k++;
    i=i+tab[i];
  }
  free(tab);
  return k-1;
}

void deplacement(animal* animal,int h,int l,nourriture *nourriture,liste *L,int energie,int seuil_reprod,liste **init,int *compte){//deplace un animal et met a jour quantite energie
  int k;
  printf("deplacement\n");

  k=geneactive(animal->chromosome);
  animal->direction=(animal->direction+k)%8;


  switch(animal->direction){
    case 0: {
      (animal->pos.i)=(animal->pos.i+1)%h;
      break;
    }

    case 1: {
      (animal->pos.i)=(animal->pos.i+1)%h;
      (animal->pos.j)=(animal->pos.i+1)%l;
      break;
    }

    case 2: {
      (animal->pos.j)=(animal->pos.j+1)%l;
      break;
    }

    case 3: {
      (animal->pos.i)=(animal->pos.i-1)%h;
      (animal->pos.j)=(animal->pos.j+1)%l;
      break;
    }

    case 4:{
      (animal->pos.i)=(animal->pos.i-1)%h;
      break;
    }

    case 5:{
      (animal->pos.i)=(animal->pos.i-1)%h;
      (animal->pos.j)=(animal->pos.j+1)%l;
      break;
    }

    case 6:{
      (animal->pos.j)=(animal->pos.j-1)%l;
      break;
    }

    case 7:{
      (animal->pos.i)=(animal->pos.i+1)%h;
      (animal->pos.j)=(animal->pos.i-1)%l;
      break;
    }
    default: break ;
    }
   if(animal->pos.i<0){
     animal->pos.i+=h;
   }
   if(animal->pos.j<0){
     animal->pos.j+=h;
   }
 printf("La nouvelle direction de l'animal est %d",animal->direction);
 etatenergie(animal,nourriture,L,energie,seuil_reprod,init,compte);
}

void etatenergie(animal * A,nourriture *nourriture,liste *L,int energie,int seuil_reprod,liste **init,int *compte){// fonction qui met a jour l'etat d'energie de l'animal
 if (presencenourriture(&A->pos,nourriture)==1){
    int k=0,p;
    for (k=0;k<nourriture->nombre;k++){
      if(A->pos.i==nourriture->TAB_N[k].i &&  A->pos.j==nourriture->TAB_N[k].j){
        for (p=k;p<nourriture->nombre-1;p++){
          nourriture->TAB_N[p].i=nourriture->TAB_N[p+1].i;
          nourriture->TAB_N[p].j=nourriture->TAB_N[p+1].j;
        }
        nourriture->nombre--;
      }
    }
    A->energie+=energie;
    printf("lenergie de lanimal est %d et le seuil de reproduction est %d",A->energie,seuil_reprod);
    if(A->energie>=seuil_reprod){
        reproduction(init,L,A);
    }
  }
  else {
      A->energie=A->energie-1;
      if (A->energie<0){//a modifier
        printf("\n \nTragiquement, l'animal est mort car il n'a plus assez d'energie.\n");
        printf("Son energie est = %d\n",A->energie);
        printf("LA taille pour parcourir la liste des descandant est %d\n",*compte);
        printf("on tente de cherche la liste dont la tete est lanimal et dans ce cas la retirer\n");
        SupprimerDansListe(init,A,compte);
        RemoveTime(L,A);
      }
  }
}

void reproduction (liste ** init,liste *L,animal *ani){ //reproduction d'un animal qui depaase le seuil d'energie
   printf("\nFelicitations! \n L'animal a un nouveau desndants \n");
   int numListeDeLani=RechercheDansListe(init,ani,L->taille);

    ani->energie=ani->energie/2;
    printf("la nouvelle energie de l'animal est %d",ani->energie);
    animal *enfant=malloc(sizeof(animal));
    if (enfant==NULL){
      printf("erreur malloc pour l'enfant reproduit");
      exit(EXIT_FAILURE);
    }
    enfant->compteur = 0;
    enfant->energie=ani->energie;
    enfant->direction=ani->direction;
    int i;
    for(i=0;i<8;i++){
      enfant->chromosome[i]=ani->chromosome[i];
    }
    mutation(ani);
    mutation(enfant);

    enfant->pos=ani->pos;
    ajout_liste(init[numListeDeLani],enfant);//elle ajoute l'enfant dans la liste du parent
    ajout_liste(L,enfant);
    afficher_animal(enfant);
    afficher_animal(ani);
  }
