#include<stdlib.h>
#include<stdio.h>
#include"monde.h"
#ifndef lirefichier_h
#define lirefichier_h

void lire_monde(FILE *f,int Tab[]);
void lire_animaux(FILE *f,liste* L);
void detruire_liste(liste *L);
void detruire_desc(liste **init,int compte);

#endif
