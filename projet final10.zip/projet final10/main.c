#include<stdio.h>
#include<stdlib.h>
#define Taille 1000
#include"monde.h"
#include"nourriture.h"
#include"affiche.h"
#include"lirefichier.h"
#include"deplace.h"
#include"distance.h"
#include<math.h>
#include<time.h>
#define N_char 255

liste * init_list(void );
void ajout_liste(liste *L,animal* ele);
int compare_animal(animal *A1,animal *A2);
void insertion_sort(int n, int* p);
int distance(animal* A,int ib, int jb,int hb,int lb);
int max(int a,int b);
double absolue(double a);
void etatenergie(animal * animal,nourriture *nourriture,liste *L,int energie,int seuil_reprod,liste **init);
int distance(animal* A,int ib, int jb,int hb,int lb);
void RemoveTime(liste *L,animal *ele);
void mutation(animal *animal);
liste *RechercheDansListe(liste **init,animal *A,int compte);
int ListeRechercheAnimal(liste *L,animal *A);

liste *init_list(void ){ // initialise une liste vide
  liste *L=malloc(sizeof(liste));
  if(L==NULL){
    printf("ERREUR malloc de listechaine");
    exit(EXIT_FAILURE);
  }
  L->tete=NULL;
  L->taille=0;
  return L;
}

void ajout_liste(liste *L,animal *ele){
  maillon *m=malloc(sizeof(maillon));
  if (m==NULL){
    printf("ERREUR maloc de maillon");
  }
  else {
    m->ani=ele;
    m->next=L->tete;
    L->tete=m;
    L->taille++;
 }
}

void removeAnimal(liste *L,animal *ele){//c pour que ca c fois efface une fois
    maillon *it=L->tete;
    while((L->tete!=NULL)&(compare_animal(it->ani,ele)==1)){
      L->tete=it->next;
      free(it);
      it=L->tete;
      L->taille--;
    }
    while((it!=NULL)&(it->next!=NULL)){
      if(compare_animal(it->next->ani,ele)==1){
        maillon *m=it->next;
        it->next=m->next;
        L->taille--;
      }
      else{it=it->next;}
    }
  }




  int compare_animal(animal *A1,animal *A2){
    if((A1->direction!=A2->direction)||(A1->energie!=A2->energie)||(A1->pos.i!=A2->pos.i)||(A1->pos.j!=A2->pos.j)){
      return 0;
    }
    for(int k=0;k<8;k++){
      if(A1->chromosome[k]!=A2->chromosome[k]){
        return 0;
      }
    }
    return 1;
  }
liste *creer_liste_famille(animal*A){
  liste *L=init_list();
  ajout_liste(L,A);
return L;
}
liste **creer_famille(liste*L,int compte){
  liste **init=malloc(compte*sizeof(liste *));
    if(init==NULL){exit(EXIT_FAILURE);}
    if(L->tete==NULL){printf("pas danimaux\n");}
    maillon *m=L->tete;
    for(int i=0;i<L->taille;i++){
    //  printf("\nCREATION FAMILLE DESCENDANTS animal numero %d \n",i);
      init[i]=creer_liste_famille(m->ani);
      m=m->next;
    //  afficher_liste(init[i]);
    }
    return init;
}


void usage(char *prog) {
    fprintf(stderr, "Usage: %s r n input.phine output.phine [c]\n\n\tr: 0 (without randomness) or 1 (with randomness)\n\tn: number of iterations\n\tc: [option] nombre of generated images after the n iterations\n", prog);
}


int main(int argc, char **argv){

 int h,l,ib,jb,hb,lb,seuil_reprod,energie,nb_tour;
 int Tab[8]={};
   int n = 0;
   char* input;
   char* output;
   int r;

   if(argc<5 || argc>6) {
      usage(argv[0]);
      return 0;
   }

   if(sscanf(argv[1], "%d", &r)!=1 || (r != 1 && r!=0)) {
      fprintf(stderr, "incorrect value for r (%s)\n", argv[1]);
      usage(argv[0]);
      return 0;
   }

   if(sscanf(argv[2], "%d", &n)!=1) {
      fprintf(stderr, "incorrect value for n (%s)\n", argv[2]);
      usage(argv[0]);
      return 0;
   }

   input=argv[3];
   output=argv[4];

  /* if(argc>5 && sscanf(argv[5], "%d", &c)!=1) {
      fprintf(stderr, "incorrect value for c (%s)\n", argv[3]);
      usage(argv[0]);
      return 0;
   }*/

   printf("args: %d %d %s %s\n", r, n, input, output);

   if(r) {
      srand(time(NULL));
   }
   nb_tour=n;
 //srand(time(NULL));

  FILE *f=fopen(input,"r");
  FILE *g=fopen(output,"w");
  if ((f==NULL) || (g==NULL)){
    printf("erreur d'ouverture ou de creation de fichier /n");
    return -1;}
    lire_monde(f,Tab);
    l=Tab[0];
    h=Tab[1];
    ib=Tab[2];
    jb=Tab[3];
    hb=Tab[4];
    lb=Tab[5];
    energie=Tab[6];
    seuil_reprod=Tab[7];

    liste *L=lire_animaux(f);
    fclose(f);
    //removeAnimal(L,A1->ani);//pour supprimer un element on efface le pointeur animal dun mailon
    int compte=L->taille;//nb animaux
    printf("\nLe nombre d'animaux presents est %d \n",L->taille);
    liste **init=creer_famille(L,compte);
    affiche_toutes_les_familles(init,compte);
    //printf("distance animal 0 =%d\n",distance(L->tete->ani,ib,jb,hb,lb));

    nourriture * N=init_nourriture(h,l,hb,lb,ib,jb);
    //affiche_nourriture(N);
 	 int c=0;
 	 while(c<nb_tour){
  	  printf("Le numero de tour est %d\n",c);
      maillon *m=L->tete;
      printf("ENERGIE vaut %d\n",energie);
      if(m==NULL){printf("liste vide\n");}
      for(int i=0;i<L->taille;i++){//faire le deplacement de chaque animal
		   deplacement(m->ani,h,l,N,L,energie,seuil_reprod,init);
       printf("\nLe nombre d'animaux presents est ss%d \n",L->taille);
        m=m->next;
      }
      c++;
      gener_nourriture(N,h,l,ib,jb,hb,lb);
  }
  //on trie la liste

  int *liste_dist=liste_des_distances(L,ib,jb,hb,lb);

  afficher_distance(liste_dist,L->taille);
  if(L->tete==NULL){
    printf("tes bete avant\n");
  }
  liste * liste_trie=liste_anim_trie(L,liste_dist,ib,jb,hb,lb);

  printf("LA LISTE TRIE PAR RAPPORT A LA BEAUCE EST:\n");

  printf("\nLe nombre d'animaux presents est %d \n",liste_trie->taille);

  afficher_liste(liste_trie);//affiche la nouvelle liste trie, le premier element est null
  //affiche_nourriture(N);
  printf("LA NOUVELLE LISTE DES DESCENDANTS EST\n");

   affiche_toutes_les_familles(init,compte);
 fprintf(g, "Le seuil de reproduction est de:%d\n",seuil_reprod);
 fprintf(g, "L'energie est de:%d\n",energie);
 for(int k=0;k<N->nombre;k++){
  fprintf(g, "Il ya de la nouriture dans cette position: i=%d j=%d\n",N->TAB_N[k].i,N->TAB_N[k].j);
 }
fprintf(g, "\nLe nombre d'animaux restant est %d\n",liste_trie->taille);
fprintf(g,"Voici les animaux tries par rapport a la BEAUCE:");
maillon *parc=L->tete;// quand je mets liste_trie ca retourne une erreur
 while(parc!=NULL){
  fprintf(g,"%d %d %d %d %d %d %d %d\n",parc->ani->chromosome[0],parc->ani->chromosome[1],parc->ani->chromosome[2],parc->ani->chromosome[3],parc->ani->chromosome[4],parc->ani->chromosome[5],parc->ani->chromosome[6],parc->ani->chromosome[7]);
  parc=parc->next;
 }
 fprintf(g,"\n \n");
 for(int k=0;k<compte;k++){
  if(init[k]->tete){
    fprintf(g, "VOICI la desandance num=%d: \n",k);
    maillon *m=init[k]->tete;
    while(m){
        fprintf(g,"%d %d %d %d %d %d %d %d\n",m->ani->chromosome[0],m->ani->chromosome[1],m->ani->chromosome[2],m->ani->chromosome[3],m->ani->chromosome[4],m->ani->chromosome[5],m->ani->chromosome[6],m->ani->chromosome[7]);
        m=m->next;
    }
    fprintf(g,"\n");
  }
 }
 fprintf(g," ");


    return 0;}
